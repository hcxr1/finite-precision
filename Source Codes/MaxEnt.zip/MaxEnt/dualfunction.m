function [Lgamma,nablaL,hessianL] = dualfunction(p,gam,x_cond,mu_cond)
% <This function does what?>
%
% Input:
% <what?>
%
% Output:
% <what?>
%
%

if nargout >= 1
    % compute the dual function, L(gamma), in expression (5.2)
    Lgamma = lgamma(p,gam,x_cond,mu_cond);
end
   
if nargout >= 2
    % compute the gradient of the dual function L(gamma), nablaL, in 
    % expression (5.5a)
    nablaL = nablal(p,gam,x_cond,mu_cond);
end
    
if nargout >= 3
    % compute the hessian of the dual function L(gamma), H, in expression
    % (5.5b)
    hessianL = hessianl(p,gam,x_cond,mu_cond);
end

if nargout ~= 1 && nargout ~= 2 && nargout ~= 3
    % unknown number of output arguments
    error('Please insert the correct number of output arguments for dualfunction.m')
end

end

function Lgamma = lgamma(p,gam,x_cond,mu_cond)
% computes the second term in the dual objective function (5.2)
%
% Input:
% p - orthogonalised polynomial
% gam - values of the gamma
% x_cond - conditioned x values
% mu_cond - conditioned moments
%
% Output;
% Lgamma - L(gamma) in expression (5.2)
%

M = length(mu_cond)-1;

% for the first term - calculation begins from the 1st moment
% integrate using Gauss-Lagendre
[x_int, c_int] = lgwt(1e2*5,x_cond(1),x_cond(end));
f = exp(expinner(M,gam,x_int,p));
term_1 = sum(c_int.*f);
% 
% intfun = @(x) exp(expinner(M,gam,x,p));
% term_1 = integral(intfun,x_cond(1),x_cond(end));

% for the second term - calculation begins from the 1st moment
term_2 = 0;
for k = 1:M+1
    p_k = p(:,k);
    polyvalue = mu_cond*p_k;
    
    term_2 = term_2+gam(k)*polyvalue;
end

% adds both the terms together
Lgamma = term_1 - term_2;
end

function nablaL = nablal(p,gam,x_cond,mu_cond)
% computes the gradient of the dual objective function (5.2), nablaL
%
% Input:
% p - orthogonalised polynomial
% gam - values of the gamma
% x_cond - conditioned x values
% mu_cond - conditioned moments
%
% Output;
% nablaL - gradient of the dual objective function (5.2), nablaL
%

M = length(mu_cond)-1;
nablaL = zeros(M,1);
for K = 1:M+1
    term_1 = qcalc(gam,x_cond,mu_cond,K,p);
    
    p_k = p(:,K);
    term_2 = mu_cond*p_k;
    
    nablaL(K) = term_1 - term_2;
end

end

function hessianL = hessianl(p,gam,x_cond,mu_cond)
% computes the hessian of the dual objective function (5.2), H
%
% Input:
% p - orthogonalised polynomial
% gam - values of the gamma
% x_cond - conditioned x values
% mu_cond - conditioned moments
%
% Output;
% hessianL - hessian of the dual objective function (5.2), nablaL
%

M = length(mu_cond)-1;
hessianL = zeros(M);
for K = 1:M+1
    for L = 1:M+1
        hessianL(K,L) = qcalc(gam,x_cond,mu_cond,K,p,L,p);
    end
end

end

function inner = expinner(M,gam,x,p)
inner = 0;
for k = 1:M+1
    inner = inner+gam(k)*polycalc(M+1,x,k,p);
end
end