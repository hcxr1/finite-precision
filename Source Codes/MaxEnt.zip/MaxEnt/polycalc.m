function polyvalue = polycalc(M,vect,k,p1,l,p2)
% substitutes the vector into the polynomial
%

% for different input arguments
if nargin == 4 % for gradient
    p_k = p1(:,k);
    
    polyvalue = 0;
    for K = 1:length(p_k)
        polyvalue = polyvalue + p_k(M-K+1)*vect.^(M-K);
    end
    
%     polyvalue = sum(bsxfun(@times, bsxfun(@power, repmat(vect,[1,9]), linspace(8,0,9)), flipud(p_k).'),2);
    
elseif nargin == 6  % for hessian
    p_k = p1(:,k);
    p_l = p2(:,l);
    
    conv_p = conv(p_k,p_l);
    IFull = length(conv_p);
    polyvalue = 0;
    for i = 1:length(conv_p)
        polyvalue = polyvalue + conv_p(IFull-i+1)*vect.^(IFull-i);
    end
    
    
else  % unknown number of input arguments
    error('Please insert the correct number of input arguments')
end
end