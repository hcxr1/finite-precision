function [gam,op,Fval,iter] = bfgs(fun,x,mu,A,op,gam,maxiter,prec,x_cond,mu_cond)
% <This function does what?>
%
% Input:
% <what?>
%
% Output:
% <what?>
%
%

iter = 0;
Fvalcon = 1; NaphlaLcon = 1; Fval = 100;

while(iter < maxiter && NaphlaLcon > prec && Fvalcon > prec)
    % increase iteration number
    iter = iter + 1;

    % save previous value and obtain the new value
    oldFval = Fval;
    [Fval,NaphlaL,HessianL] = fun(gam);
    
    % error checking
    if Fval < 0
        gam = zeros(size(gam));
        break
    end
    
    % find the condition number of the inverse Hessian
    condk = cond(inv(HessianL));
    
    % perform reorthogonalization if condition number above 20. Else update
    % gamma
    if condk > 20
        [op,gam] = orthopoly(op,gam,x_cond,mu_cond);
        fun = @(gam)dualfunction(op,gam,x_cond,mu_cond);
        [Fval,NaphlaL,HessianL] = fun(gam);
    end
    
    % update using line search
    dir = -(HessianL\NaphlaL);
    step = linsearch(gam,1,dir,fun);    
    gam = gam + step*dir;
    
    % calculate conditions
    Fvalcon = abs((oldFval-Fval)/Fval);
    NaphlaLcon = max(abs(NaphlaL));
    
    % plot distribution
    tlambda = -1*op*gam;
    tlambda(1) = tlambda(1) - log(A);
    
    ttlambda = invcondgamma(tlambda,A,mu(1));
    [p,c] = calcp(ttlambda,x);
    plot(x,p)
    axis tight
    pause(0.01)
end
end

function lambda = linsearch(X,lambda,D,myFx)

MaxIt = 1000;
Toler = 1e-4;

iter = 0;
bGoOn = true;
while bGoOn
    iter = iter + 1;
    if iter > MaxIt
        lambda = 0;
        break
    end
    
    h = 0.01 * (1 + abs(lambda));
    f0 = myFxEx(X, D, lambda, myFx);
    fp = myFxEx(X, D, lambda+h, myFx);
    fm = myFxEx(X, D, lambda-h, myFx);
    deriv1 = (fp - fm) / 2 / h;
    deriv2 = (fp - 2 * f0 + fm) / h ^ 2;
    if deriv2 == 0
        break
    end
    diff = deriv1 / deriv2;
    lambda = lambda - diff;
    if abs(diff) < Toler
        bGoOn = false;
    end
end
end

function y = myFxEx(X, DeltaX, lambda, myFx)

X = X + lambda * DeltaX;
y = myFx(X);
end

function lambda = invcondgamma(gam_cond,A,mean)
% <This function does what?>
%
% Input:
% <what?>
%
% Output:
% <what?>
%
%

% rotated to centralized lambda
lambda_trans = zeros(length(gam_cond),1);
for i = 1:length(gam_cond)
    iReal = i-1;
    lambda_trans(i) = A.^iReal*gam_cond(i);
end

% centralized to original lambda
lambda = zeros(size(lambda_trans));
for i = 1:length(lambda_trans)
    iReal = i-1;
    for j = i:length(lambda_trans)
        jReal = j-1;
        lambda(i) = lambda(i) + (-1)^(jReal-iReal)*nchoosek(jReal,iReal)*lambda_trans(j)*(mean)^(jReal-iReal);
    end
end
end

function [p,c] = calcp(gam_final,x)
% <This function does what?>
%
% Input:
% <what?>
%
% Output:
% <what?>
%
%

M = length(gam_final);
fun = @(x) exp(-(gam_final(1)+innercalc(M-1,gam_final(2:end),x)));
p = fun(x);
c = integral(fun,x(1),x(end));
end

function temp = innercalc(M,gam_final,x)
% <This function does what?>
%
% Input:
% <what?>
%
% Output:
% <what?>
%
%

temp = 0;
for K = 1:length(gam_final)
    KReal = K - 1;
    temp = temp + gam_final(M-KReal)*x.^(M-(KReal));
end
end