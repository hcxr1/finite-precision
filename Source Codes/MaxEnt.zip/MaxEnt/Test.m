% Written by Arvind Rajan
% 1/9/2016
%
% Test file for getbounds.m and myabramem.m function files
%
clc; clear; close all;
set(0,'DefaultFigureWindowStyle','docked')

load('EP500model6')

% Choose the number of moments 
n = length(EP);

% Find the raw moments of the distribution
mu_raw = [1 EP'];

% Find the bounds using nth order raw moments with getbounds.m
% WARNING: For more than n=4 moments, use pt < 1e-3, e.g., pt = 1e-4
pt = 10^-(floor(n/2)+1);
% pt = 10^-7;
bounds = getbounds(mu_raw,pt);

% Find the distribution using maximum entropy method
x = linspace(bounds(1),bounds(2),1000);
[p,lambda] = myabramem(mu_raw(2:end),x);

% Plot the distribution
plot(x,p,'LineWidth',1.5)
legend('Maximum Entropy')
title('EP1000model5')
% print('EP1000model5','-dpng','-r300')