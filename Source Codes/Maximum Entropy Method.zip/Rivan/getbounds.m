function bounds = getbounds(mu_raw,pt)
% Written by Arvind Rajan
% 1/9/2016
%
% Function file that gives lower and upper bounds for supplied raw moments
%
% Inputs: mu_raw - 0,...,nth order raw moments of the distributions
%         pt     - probability bound (preferebally 1e-3 or 1e-4)
% 
% Output: bounds - lower and upper bounds of the distribution
%

n = length(mu_raw)-1;
syms C; m = sym('m',[1,n+1]);
mu = vpa(zeros(size(m)));
for j = 1:n+1
    iReal = j-1;
    for k = 0:iReal
        mu(j) = mu(j)+nchoosek(iReal,k)*(-C)^(iReal-k)*m(k+1);
    end
end

if(mod(length(mu),2) ~= 0) % when even number of moments are provided
    n_p = (length(mu)-1)/2+1;
else % when odd number of moments are provided
    n_p = floor((length(mu)-1)/2)+1;
end

D1 = hankel(mu(1:n_p),mu(n_p:2*n_p-1));
D2 = hankel(mu(3:n_p+1),mu(n_p+1:2*n_p-1));
p_sym = det(D1)/det(D2);

for i = 1:n+1
    p_sym = subs(p_sym,m(i),mu_raw(i));
end

[N,D] = numden(p_sym);
r = roots(sym2poly(D*pt-N));
sel = r == real(r);
b = r(sel);

if b(1) < b(end)
    bounds = [b(1) b(end)];
else
    bounds = [b(end) b(1)];
end
end