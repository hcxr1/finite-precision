function Q = qcalc(gam,x_cond,mu_cond,k,p1,l,p2)
% calculate the expression Q in (5.6)
%

K = length(mu_cond);
[x_int, c_int] = lgwt(1e2/2,x_cond(1),x_cond(end));

% different g_x depending on the number of input arguments
if nargin == 5
    g_x = polycalc(K,x_int,k,p1);
elseif nargin == 7
    if p2 == 1
        g_x = 1;
    else
        g_x = polycalc(K,x_int,k,p1,l,p2);
    end
else  % unknown number of input arguments
    error('Please insert the correct number of arguments to calculate quadrature Q')
end

% for loop to calculate the argument of exponential function in rho
inner = 0;
for k = 1:K
    inner = inner+gam(k)*polycalc(K,x_int,k,p1);
end

f = g_x.*exp(inner);
Q = sum(c_int.*f);

end