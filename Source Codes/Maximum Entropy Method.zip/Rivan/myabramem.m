function [p, lambda] = myabramem(mu,x)
% myabrammem
% method by Rafail V. Abramov
%
% Reference: 
% 1. A practical computational framework for the multidimensional
%    moment-constrained maximum entropy principle
% 2. An improved algorithm for the multidimensional
%    moment-constrained maximum entropy problem
% 3. The multidimensional maximum entropy moment problem: a review on
%    numerical methods
%
% Written by : Arvind Rajan
% Date : 25-03-2016
%

% number of moments, M and K parameter
M = length(mu);
K = M+1;

% ------------------------------------------------------------------------
% Step 1: precondition input constraints by setting zero mean as in [1]
% ------------------------------------------------------------------------
% lineary transform mu for mean of pdf to be 0
[mu_trans, x_trans] = centraltransform(mu,x);

% condition the moments such that the variance is 1
[mu_cond,x_cond,A] = rotation(mu_trans,x_trans);

% ------------------------------------------------------------------------
% Step 2: generate a set of M random linearly independant polynomials p_k
% of Mth order
% ------------------------------------------------------------------------
% generate a random set of linearly independant polynomials
op = eye(K);

% initializing the gamma based on Gaussian distribution
gam0 = zeros(K,1);
gam0(3) = -10^(-10);

% perform modified grand-schmidt orthogonalization
[op,gam0] = orthopoly(op,gam0,x_cond,mu_cond);
fun = @(gam)dualfunction(op,gam,x_cond,mu_cond);

% minFunc
addpath(genpath(pwd))
options = [];
options.display = 'iter';
options.Method = 'newton';
% options.Method = 'lbfgs';
% options.maxFunEvals = 1500;
% options.maxIter = 100;
% options.optTol = 1e-6;
% options.progTol = 1e-4;
[gam,op,~,~, ~] = minFunc(fun,gam0,op,x_cond,mu_cond,options);
rmpath(genpath(pwd))

lambda = -1*op*gam;
lambda(1) = lambda(1) - log(A);

lambda = invcondgamma(lambda,A,mu(1));
p = calcp(lambda,x);

% ------------------------------------------------------------------------
% Step 3: choose the set of Lagrange multipliers Lambda_k corresponding to
% the Gaussian distribution with zero mean
% ------------------------------------------------------------------------
end

% ------------------------------------------------------------------------
% Supporting functions belows this point
% ------------------------------------------------------------------------
function [mu_trans,x_trans] = centraltransform(mu,x)
% function to perform perform central transformation on mu
%
% Input:
% mu - raw moments (1 to n)
% x - x values
%
% Output:
% mu_trans - linearly (cenral) transformed mu (0 to n)
% x_trans - linearly (cenral) transformed x
%

% number of moments (1 to n)
M = length(mu);

% linearly transforming mu
mu_trans = zeros(1,M+1);
for i = 0:M
    for j = 0:i
        if (i-j == 0)
            mu_trans(i+1) = nchoosek(i,j)*(-1)^(j)*1*mu(1)^j + mu_trans(i+1);
        else
            mu_trans(i+1) = nchoosek(i,j)*(-1)^(j)*mu(i-j)*mu(1)^j + mu_trans(i+1);
        end
    end
end

% transforming x: x - mean
x_trans = x - mu(1);
end

function [mu_cond,x_cond,A] = rotation(mu_trans,x_trans)
% function to perform perform rotation on centralised mu with the alhpa
% scaling included
%
% Input:
% mu_trans - mu after performing central transformation (0 to n)
% x_trans - x values after performing central transformation
%
% Output:
% mu_cond - rotated mu (0 to n)
% x_cond - x corresponding to rotated mu
% A - rotation matrix with the alhpa scaling included
%

% number of moments (1 to n)
M = length(mu_trans)-1;

% obtaining the rotation matrix with the alhpa scaling included
% A = 1/sqrt(mu_trans(3)); % without alpha scaling
A = 1/sqrt(mu_trans(3))/nthroot(prod(1:2:2*M-1),2*M); % with alpha scaling

% rotating mu
mu_cond = zeros(1,M+1);
for i = 1:M+1
    if i==1 || i==2
        mu_cond(i) = mu_trans(i);
    else        
        iReal = i-1;
        mu_cond(i) = A.^iReal*mu_trans(i);
    end
end

% find x-values corresponding to rotated mu
x_cond = A*x_trans;
end

function lambda = invcondgamma(gam_cond,A,mean)
% <This function does what?>
%
% Input:
% <what?>
%
% Output:
% <what?>
%
%

% rotated to centralized lambda
lambda_trans = zeros(length(gam_cond),1);
for i = 1:length(gam_cond)
    iReal = i-1;
    lambda_trans(i) = A.^iReal*gam_cond(i);
end

% centralized to original lambda
lambda = zeros(size(lambda_trans));
for i = 1:length(lambda_trans)
    iReal = i-1;
    for j = i:length(lambda_trans)
        jReal = j-1;
        lambda(i) = lambda(i) + (-1)^(jReal-iReal)*nchoosek(jReal,iReal)*lambda_trans(j)*(mean)^(jReal-iReal);
    end
end
end

function p = calcp(gam_final,x)
% <This function does what?>
%
% Input:
% <what?>
%
% Output:
% <what?>
%
%

M = length(gam_final);
fun = @(x) exp(-(gam_final(1)+innercalc(M-1,gam_final(2:end),x)));
p = fun(x);
end

function temp = innercalc(M,gam_final,x)
% <This function does what?>
%
% Input:
% <what?>
%
% Output:
% <what?>
%
%

temp = 0;
for K = 1:length(gam_final)
    KReal = K - 1;
    temp = temp + gam_final(M-KReal)*x.^(M-(KReal));
end
end