function [p,gam] = orthopoly(a,gam,x_cond,mu_cond)
% <This function does what?>
%
% Input:
% <what?>
%
% Output:
% <what?>
%
%

K = length(mu_cond);
a_init = a; p = a; gam_init = gam;

for k = 1:K
    for l = 1:2
        for m = 1:k-1
            a(:,k) = a(:,k) - qcalc(gam,x_cond,mu_cond,k,a,m,p)*p(:,m);
            gam = a\(a_init*gam_init);
        end
    end
    p(:,k) = a(:,k)/sqrt(qcalc(gam,x_cond,mu_cond,k,a,k,a));
end

% recompute Lagrange multipliers, gamma
gam = p\(a_init*gam_init);

% delete this after checking is done
% for k = 1:K
%     for l = 1:K
%         val(k,l) = qcalc(gam,x_cond,mu_cond,k,p,l,p);
%     end
% end
% delete this after checking is done
end