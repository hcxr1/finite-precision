% Written by Arvind Rajan
% 1/9/2016
%
% Test file for getbounds.m and myabramem.m function files
%

% Choose the distribution
% testfun = @(x) wblpdf(x,1,1.0);
% testfun = @(x) normpdf(x,0,1);
% testfun = @(x) unifpdf(x,0,1);

% Choose the number of moments 
n = 4;

% Find the raw moments of the distribution
mu_raw = ones(1,n+1);
for i = 1:n
    f = @(x) x.^i.*testfun(x);
    mu_raw(i+1) = integral(f,-Inf,Inf);
end

% Find the bounds using nth order raw moments with getbounds.m
% WARNING: For more than n=4 moments, use pt < 1e-3, e.g., pt = 1e-4
pt = 1e-3;
bounds = getbounds(mu_raw,pt);

% Find the distribution using maximum entropy method
x = linspace(bounds(1),bounds(2),1000);
p = myabramem(mu_raw(2:end),x);

% Plot the distribution
plot(x,p,'LineWidth',1.5), hold on
plot(x,testfun(x),'LineWidth',1.5), hold off
legend('Maximum Entropy','Analytical')