function s = getround
%GETROUND     Dummy routine to shadow INTLAB if not available
%

% written  06/12/98     S.M. Rump
%

  s = 0;
  