function c = diam(A)
%DIAM         implements  diam(A)  for fl-type
%
%   c = diam(A)
%

% written  11/06/13     S.M. Rump
%

  A = A.value;
  if isa(A,'intval')
    e = 1e-30;
    if 1+e==1-e                           % fast check for rounding to nearest
      rndold = 0;
    else
      rndold = getround;
      setround(0)
    end
    setround(1)
    c = fl(A.sup)-A.inf;
    setround(rndold)
  else
    c = fl(0);
  end
    