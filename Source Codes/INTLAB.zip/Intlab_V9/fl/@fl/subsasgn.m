function c = subsasgn(c,s,b)
%SUBSASGN     Implements subscripted assignments for fl-type
%
%   example   C(i,:) = A
%

% written  11/07/13     S.M. Rump
%

  if length(s)>1
    error('multiple indexing for fl-type assignment not allowed')
  end

  if strcmp(s.type,'()')     % subarray assignment c(i,j) = b
  % on entry, l.h.s. c is either of fl-type or, not defined.
  % The latter case is equivalent to isa(c,'fl')=0, because
  % always exist('c')=1.
    if ~isa(b,'fl')
      b = fl(b);
    end
    if ~isa(c,'fl')
      c.value = [];
      c = class(c,'fl');
    end
    if isempty(b.value)
      c.value(s.subs{:}) = [];
    else
      c.value(s.subs{:}) = b.value;
    end
  elseif strcmp(s.type,'.')      % subfield access
    if strcmp(s.subs,'value')
      error('for safety, explicit assignment of C.value=A not allowed; use C=fl(A).')
    elseif strcmp(s.subs,'inf')
      error('for safety, explicit assignment of C.inf=A not allowed.')
    elseif strcmp(s.subs,'sup')
      error('for safety, explicit assignment of C.value=A not allowed.')
    else
      error('invalid call of subsasgn')
    end
  else
    error('invalid call of subsasgn')
  end

  % avoid Matlab 6.5f bug: 
  % a = sparse([],[],[],1,1); a = reshape(a,1,1); abs(a)
  % produces  9.6721e-317  or similar number in underflow range
  if prod(size(c.value))==1
    c.value = full(c.value);
  end
    