function n = numel(varargin)
%NUMEL        Overloaded functions, necessary for Matlab V6.1f
%

% written  10/21/13     S.M. Rump
%

  n = 1;
