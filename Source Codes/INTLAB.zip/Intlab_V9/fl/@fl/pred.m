function R = pred(A,k)
%PRED         fl-predecessor of fl-type A
%
%   R = pred(A)
%
%On return, R consists of the (elementwise) smallest fl-numbers with A > R.
%Similarly,
%
%   R = pred(A,k)
%
%produces the  k-th predecessor. Negative k yields k-th successor.
%

% written  10/31/13     S.M. Rump
% modified 04/23/14     S.M. Rump  set/getappdata replaced by global
%

  global INTLAB_CONST

  if isa(A,'intval')
    error('function predecessor not for fl-type intervals')
  end

  e = 1e-30;
  if 1+e==1-e                           % fast check for rounding to nearest
    rndold = 0;
  else
    rndold = getround;
    setround(0)
  end

  const = INTLAB_CONST.FL_CONST;        % initialize constants
  eta = const.subrealmin;

  if nargin==1
    k = 1;
  end

  R = A;
  if k<0
    setround(1)
    for i=1:(-k)
      R = R + eta;
    end
  else
    setround(-1)
    for i=1:k
      R = R - eta;
    end
  end
    
  setround(rndold)
  