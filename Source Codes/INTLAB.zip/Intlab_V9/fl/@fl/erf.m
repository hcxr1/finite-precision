function A = erf(A)
%ERF             Implements  erf(x)  for fl-type (intervals)
%
%  y = erf(x)
%

% written  04/22/14  S.M. Rump
%

  if isa(A.value,'intval')
    A = fl(erf(A.value));
  else                      % double input
    
    e = 1e-30;
    if 1+e==1-e         	% fast check for rounding to nearest
      rndold = 0;
    else
      rndold = getround;
      setround(0)
    end
    
    A = fl(erf(A.value));   % make sure rounding to nearest
    
    if rndold               % restore rounding mode
      setround(rndold)
    end
    
  end
  