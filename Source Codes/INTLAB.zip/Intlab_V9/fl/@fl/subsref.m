function c = subsref(a,s)
%SUBSREF      Implements subscripted references for fl-type
%
%   example   C = A(:,3:5)
%

% written  11/07/13     S.M. Rump
%

  while 1
    if ~isa(a,'fl')                   % for a.inf(i) etc.
      c = subsref(a,s(1));
    elseif strcmp(s(1).type,'()')     % index reference a(i,j)
      c.value = a.value(s(1).subs{:});
      % avoid Matlab 6.5f bug:
      % a = sparse([],[],[],1,1); a = reshape(a,1,1); abs(a)
      % produces  9.6721e-317  or similar number in underflow range
      if prod(size(c.value))==1
        c.value = full(c.value);
      end
      c = class(c,'fl');
    elseif strcmp(s(1).type,'.')     % subfield access
      if strcmp(s(1).subs,'value')
        c = a.value;
      elseif strcmp(s(1).subs,'inf')
        if isa(a.value,'intval')
          c = a.value.inf;
        else
          c = a.value;
        end
      elseif strcmp(s(1).subs,'sup')
        if isa(a.value,'intval')
          c = a.value.sup;
        else
          c = a.value;
        end
      else
        error('invalid subscript reference for intval')
      end
    else
      error('invalid index reference for intval')
    end
    if length(s)==1
      return
    end
    s = s(2:end);
    a = c;
  end
