function A = log2(A)
%LOG2            Implements  log2(x)  for fl-type (intervals)
%
%  y = log2(x)
%

% written  04/22/14  S.M. Rump
%

  if isa(A.value,'intval')
    RealStdFctsExcptn = intvalinit('RealStdFctsExcptn',0);
    intvalinit('RealStdFctsExcptnNaN',0);
    A = fl(log2(A.value));
    intvalinit(RealStdFctsExcptn,0);
  else                      % double input
    
    e = 1e-30;
    if 1+e==1-e         	% fast check for rounding to nearest
      rndold = 0;
    else
      rndold = getround;
      setround(0)
    end
    
    y = log2(A.value);      % make sure rounding to nearest
    if isreal(y)
      A = fl(y);
    else
      index = ( imag(y(:))~=0 );
      if any(index)
        y(index) = NaN;
      end
      A = fl(real(y));
    end
    
    if rndold               % restore rounding mode
      setround(rndold)
    end
    
  end
  