function r = isintval(A)
%ISINTVAL     Returns 1 if  A  is fl-type intval
%
%   r = isintval(A)
%

% written  11/06/13     S.M. Rump
%

  r = isintval(A.value);
