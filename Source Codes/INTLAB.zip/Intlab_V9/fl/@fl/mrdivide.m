function C = mrdivide(A,B)
%MRDIVIDE     fl-type division  A / B
%

% written  10/21/13     S.M. Rump
%

  if isa(A,'fl')
    A = A.value;
  end

  if isa(B,'fl')
    B = B.value;
  end

  if prod(size(B))~=1
    error('division only for scalar divisor.')
  end
  
  C = fl( A / B );
  