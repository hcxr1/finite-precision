function r = power(a,b)
%POWER        fl-type integer power  A .^ k
%

% written  03/06/14     S.M. Rump
%

  r = a^b;
  