function A = uminus(A)
%UMINUS       Implements  -f  for fl-type
%

% written  10/21/13  S.M. Rump
%

  A.value = -A.value;
  