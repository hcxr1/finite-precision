function c = mig(A)
%MIG          mignitude(a)  for fl-type
%
%   c = mig(A)
%

% written  11/06/13     S.M. Rump
%

  c = mig(A.value);
  