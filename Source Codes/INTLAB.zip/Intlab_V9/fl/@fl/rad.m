function c = rad(A)
%RAD          Implements  rad(A)  for fl-type intervals
%
%   c = rad(A)
%
% mid(A) and rad(A) computed such that
%    alpha  in  < mid(A) , rad(A) >  for all alpha in A 
% see intval/rad
%

% written  11/06/13     S.M. Rump
%

  A = A.value;
  if isa(A,'intval')
    e = 1e-30;
    if 1+e==1-e                           % fast check for rounding to nearest
      rndold = 0;
    else
      rndold = getround;
      setround(0)
    end
    setround(1)
    c = A.inf + 0.5*(fl(A.sup)-A.inf);
    c = c - A.inf;
    setround(rndold)
  else
    c = fl(0);
  end
  