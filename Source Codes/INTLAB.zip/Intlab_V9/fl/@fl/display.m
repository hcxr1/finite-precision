function display(A)
%DISPLAY      Command window display for fl-type
%

% written  10/21/13     S.M. Rump
%

  if isa(A.value,'intval')
    disp(['fl-type intval ' inputname(1) ' ='])
  else
    disp(['fl-type ' inputname(1) ' ='])
  end
  disp(A)
  