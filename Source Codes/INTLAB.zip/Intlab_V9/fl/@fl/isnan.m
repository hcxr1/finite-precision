function r = isnan(A)
%ISNAN        Array of 1's for NaN components
%
%   r = isnan(A)
%

% written  10/21/13     S.M. Rump
%

  r = isnan(A.value) ;

