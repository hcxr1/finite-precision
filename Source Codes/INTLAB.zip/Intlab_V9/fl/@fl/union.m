function union(varargin)
%UNION        For fl-type interval union, please use "hull"
%

% written  11/07/13     S.M. Rump
% modified 05/18/14     S.M. Rump  code optimization
%

  error('For fl-type interval union, please use "hull".')
  