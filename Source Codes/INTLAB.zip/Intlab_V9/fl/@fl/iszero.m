function r = iszero(A)
%ISZERO       Array of 1's for zero components
%
%   r = iszero(A)
%

% written  10/21/13     S.M. Rump
%

  r = iszero(A.value) ;

