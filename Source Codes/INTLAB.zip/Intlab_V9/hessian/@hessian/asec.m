function a = asec(a)
%ACSC         Hessian inverse secans  asec(a)
%

% written  10/07/12     S.M. Rump
%

  a = acos(1./a);
  