function demointlab
%DEMOINTLAB   Wrapper routine to call INTLAB demos
%
%A selection of INTLAB demos, call
%
%  demointlab
%

% written  10/13/12     S.M. Rump  
% modified 11/07/12     S.M. Rump  INTLAB_larger added
% modified 04/04/14     S.M. Rump  end function
% modified 05/13/14     S.M. Rump  new demos
% modified 01/21/15     S.M. Rump  error if no web available
%

  if ~exist('web','file')
    error(['Command "web" not supported. ', ...
           'To see INTLAB demo-files please display the corresponding ' ...
           'html-files in directory demos/html directly by some browser.     '])
  end    

  d = which('demointlab');
  addpath([ d(1:end-13) '\html' ])
  
  clc
  disp('Welcome to INTLAB, the Matlab toolbox for reliable computing.')
  disp(' ')
  disp('The current version 9 consists of more than 1100 .m-functions with more ')
  disp('  than 40 thousand lines of Matlab-code (more than 70 KLOC with comments). ')
  disp('The test suite for INTLAB consists of another 70 KLOC. ')
  disp(' ')
  disp(' ')
  while 1
    displaycomments
    str = input('select demo ','s');
    switch lower(str)
      case '1', web('dintlab_larger.html');
      case '2', web('dintlab.html');
      case '3', web('dintval.html');
      case '4', web('darithmetic.html');
      case '5', web('daffari.html');
      case '6', web('dfl.html');
      case '7', web('dutility.html');
      case '8', web('dstdfcts.html');
      case '9', web('daccsumdot.html');
      case 'a', web('dgradient.html');
      case 'b', web('dhessian.html');
      case 'c', web('dtaylor.html');
      case 'd', web('dslope.html');
      case 'e', web('dpolynom.html');
      case 'f', web('dlong.html');
      case '0', break;
    end
  end
  
  disp(' ')
  disp('Enjoy INTLAB. Comments and suggestions always welcome to rump (at) tuhh.de .')
  disp(' ')
  
end  % function demointlab

  
  
function displaycomments
  disp(' ')
  disp('This is a wrapper routine to call several INTLAB demos, selected by numbers. ')
  disp(' ')
  disp('1  Some larger examples with INTLAB')
  disp('2  A general demo of some features of INTLAB')
  disp('3  Some examples of interval computations')
  disp('4  Details about interval arithmetic')
  disp('5  Affine interval arithmetic')
  disp('6  fl-numbers: k-bit point and interval arithmetic')
  disp('7  Utility routines')
  disp('8  Accurate standard functions')
  disp('9  Accurate summation and dot products')
  disp('a  The gradient toolbox (gradients of multivariate functions)')
  disp('b  The Hessian toolbox (Hessians of multivariate functions)')
  disp('c  The Taylor toolbox (taylor expansion of univariate functions)')
  disp('d  The slope toolbox (slope of multivariate functions')
  disp('e  The polynomial toolbox (univariate and multivariate polynomials')
  disp('f  The long number toolbox (a rudemantary implementation, originally for internal use)')
  disp(' ')
  disp('0  exit this wrapper')
  disp(' ')
end  % function displaycomments
