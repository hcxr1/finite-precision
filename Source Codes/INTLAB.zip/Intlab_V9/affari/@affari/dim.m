function c = dim(a)
%DIM          Dimension of a square matrix 
%
%  c = dim(a);
%

% written  03/08/14     S.M. Rump
%

  c = dim(a.mid);