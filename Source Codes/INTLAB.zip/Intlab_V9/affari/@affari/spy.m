function spy(A)
%SPY          Spy sparse affari matrix
%
%   spy(A)
%

% written  08/09/02     S.M. Rump 
%

  spy(mag(A))
  