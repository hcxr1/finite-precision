function res = isnan(a)
%ISNAN          Array of 1's for NaN components
%
%   res = isnan(a)
%

% written  08/03/14  S.M. Rump
%

  res = isnan(a.range);
  