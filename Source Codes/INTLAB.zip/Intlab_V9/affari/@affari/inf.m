function r = inf(a)
%INF          Lower bound for affine arithmetic
%
%   r = inf(a)
%

% written  12/06/13  S.M. Rump
%

  r = inf(intval(a));
  