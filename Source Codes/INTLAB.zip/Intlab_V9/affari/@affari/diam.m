function c = diam(a)
%DIAM         diameter for affine arithmetic
%
%  c = diam(a);
%

% written  03/08/14     S.M. Rump
%

  c = diam(a.range);
