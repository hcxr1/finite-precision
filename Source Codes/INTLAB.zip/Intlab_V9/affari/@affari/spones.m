function c = spones(a)
%SPONES       Implements  spones(a)  for sparse affari matrix
%
%   c = spones(a)
%

% written  08/09/02     S.M. Rump 
%

  c = spones(intval(a));
  