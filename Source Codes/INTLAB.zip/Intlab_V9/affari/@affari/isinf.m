function res = isinf(a)
%ISINF          Array of 1's for inf components
%
%   res = isinf(a)
%

% written  08/03/14  S.M. Rump
%

  res = isinf(a.range);
  