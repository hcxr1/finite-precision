function r = mrdivide(a,b)
%MRDIVIDE     Affine arithmetic division  a / b   (b must be scalar)
%

% written  12/06/13  S.M. Rump
%

  if prod(size(b))~=1
    error('affine arithmetic division only for scalar denominator')
  end
  
  r = a./b;
  