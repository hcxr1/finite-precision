function r = acsc(a)
%ACSC         Affine arithmetic elementwise inverse cosecans  acsc(a)
%

% written  03/31/14     S.M. Rump
%

  r = asin(1./a);
  