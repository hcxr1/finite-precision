function t = typeof(A)
%TYPEOF       Type of A
%
%   t = typeof(A)
%
%For details, see intval\typeof and intval\typeadj.
%

% written  04/04/14     S.M. Rump
%

% affari\@affari\typeof:  a  must be affari
  t = 'affari';
