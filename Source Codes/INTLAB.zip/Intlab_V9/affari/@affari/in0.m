function res = in0(a,b)
%IN0          Implements  a in interior(b)  entrywise for affaris a and b
%

% written  08/03/14  S.M. Rump
%

  res = in0(intval(a),intval(b));
  