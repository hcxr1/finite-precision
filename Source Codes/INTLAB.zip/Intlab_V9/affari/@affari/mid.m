function r = mid(a)
%MID          Midpoint of affine arithmetic
%
%   r = mid(a)
%

% written  12/06/13  S.M. Rump
% modified 05/17/14     S.M. Rump  code optimization
%

  r = mid(a.range);
