function res = isaffari(a)
%ISAFFARI     returns 1 if a is affari (for completeness)
%
%   res = isffari(a)
%

% written  08/03/14  S.M. Rump
% modified 05/17/14     S.M. Rump  code optimization
%

  res = true;
  