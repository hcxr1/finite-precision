function c = mig(a)
%MIG          mignitude for affine arithmetic
%
%  c = mig(a);
%

% written  03/08/14     S.M. Rump
%

  c = mig(intval(a));
