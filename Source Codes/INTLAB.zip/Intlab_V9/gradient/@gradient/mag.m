function res = mag(A)
%MAG          Magnitude for gradients
%
%  res = mag(A)
%
%The result is a real quantity.
%

% written  04/04/14     S.M. Rump 
%

  res = mag(A.x);
  