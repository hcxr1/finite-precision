function r = rad(a)
%RAD          Gradient radius
%
%  r = rad(a)
%

% written  10/16/98     S.M. Rump
% modified 04/04/04     S.M. Rump  set round to nearest for safety
% modified 04/06/05     S.M. Rump  rounding unchanged
% modified 04/04/14     S.M. Rump  output float
%

  r = rad(a.x);
